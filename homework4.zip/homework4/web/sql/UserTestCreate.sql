CREATE TABLE library (
  FirstName VARCHAR(50), 
  LastName VARCHAR(50), 
  EmailAddress VARCHAR(50), 
  BookTitle VARCHAR(50),
  DueDate DATE,
 


  PRIMARY KEY (BookTitle)
)